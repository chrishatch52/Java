package game;




/**
 * @author chris
 *
 */
public interface I_Visitor {

	public void visit(ALevel level);

}
