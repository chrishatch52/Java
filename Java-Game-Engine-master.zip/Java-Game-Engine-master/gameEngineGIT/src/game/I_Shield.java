package game;



/**
 * 
 */

/**
 * @author chris
 *
 */
public interface I_Shield {

	public void addShield(AItem shield);
}
