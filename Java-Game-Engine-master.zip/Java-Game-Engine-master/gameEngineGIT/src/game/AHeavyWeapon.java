package game;


/**
 * @author chris
 *
 */
public abstract class AHeavyWeapon extends AWeapon {



	public AHeavyWeapon(String name, Bonus bonus, boolean equipped, String condition) 
	{
		super(name, bonus, equipped, condition);
	}
	
}
