package game;



/**
 * 
 */

/**
 * @author Chris
 *
 */
public interface I_LightEquip {

	public void addLarmor(ALightArmor lightArmor);
	public void addScroll(AItem scroll);
	public void addLweapon(AWeapon lightWeapon);
	
}
