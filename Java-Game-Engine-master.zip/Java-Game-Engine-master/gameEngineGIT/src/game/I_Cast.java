package game;



/**
 * 
 */

/**
 * @author chris
 *
 */
public interface I_Cast {

	public String spell(AGameCharacterFactory characters);
	public String heal();
}
