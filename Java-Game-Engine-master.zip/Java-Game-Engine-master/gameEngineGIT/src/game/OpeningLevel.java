/**
 * 
 */
package game;

/**
 * @author chris
 *
 */
public class OpeningLevel extends ALevel {

	/**
	 * @param gguys 
	 * @param levelName
	 */
	public OpeningLevel(GoodGuyFactory gguys) {
		super("opening", gguys);
	}

}
