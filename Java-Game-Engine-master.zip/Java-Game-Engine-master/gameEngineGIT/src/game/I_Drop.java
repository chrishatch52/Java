package game;



/**
 * 
 */

/**
 * @author chris
 *
 */
public interface I_Drop {//command

	public AItem dropItem();
	public void set_dropItem(AItem toDrop);
}
