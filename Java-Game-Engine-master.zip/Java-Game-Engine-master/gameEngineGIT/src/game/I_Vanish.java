package game;



/**
 * @author chris
 *
 */
public interface I_Vanish {

	public String vanish();
}
