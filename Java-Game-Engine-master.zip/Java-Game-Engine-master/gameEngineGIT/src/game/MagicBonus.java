package game;


/**
 * @author chris
 *
 */
public class MagicBonus extends AStatBonus {

	/**
	 * @param rating
	 * @param type
	 */
	public MagicBonus(int rating, String type) {
		super(rating, type);
		// TODO Auto-generated constructor stub
	}
	public MagicBonus() {
		super(0, "");
	}
}
