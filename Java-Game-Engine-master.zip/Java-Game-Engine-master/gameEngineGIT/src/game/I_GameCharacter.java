package game;

/**
 * @author chris
 *
 */
public interface I_GameCharacter {

	public String get_name();
}
