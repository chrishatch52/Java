package game;



/**
 * 
 */

/**
 * @author Chris
 *
 */
public interface I_GroupHeal {

	public String groupHeal(AGameCharacterFactory characters);
}
