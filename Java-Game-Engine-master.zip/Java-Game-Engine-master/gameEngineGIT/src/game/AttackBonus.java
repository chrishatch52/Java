package game;


/**
 * @author chris
 *
 */
public class AttackBonus extends AStatBonus {

	/**
	 * @param rating
	 * @param type
	 */
	public AttackBonus(int rating, String type) {
		super(rating, type);
		// TODO Auto-generated constructor stub
	}

	public AttackBonus() {
		super(0, "");
	}

}
