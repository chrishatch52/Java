/**
 * 
 */
package game;

/**
 * @author chris
 *
 */
public interface I_Ability {

	public String getDesc();
	public int getRating();
	public boolean isGroupAbility();
	
}
