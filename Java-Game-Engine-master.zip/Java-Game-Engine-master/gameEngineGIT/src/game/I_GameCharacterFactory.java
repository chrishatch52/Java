package game;



/**
 * @author Chris
 *
 */
public interface I_GameCharacterFactory {

	public void addGroupOne();
	public void addGroupTwo();
	public void addGroupThree();
	public void addGroupFour();
	public void addGroupFive();
	public void addGroupSix();
}
