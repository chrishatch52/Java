package game;


/**
 * @author chris
 *
 */
public class AHeavyArmor extends AArmor {

	
	public AHeavyArmor(String name, Bonus bonus,
			boolean equipped, String condition) {
		super(name, bonus, equipped, condition);
	}

}
