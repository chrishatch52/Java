/**
 * 
 */
package gfx;

import javax.swing.*;

/**
 * @author chris
 *
 */
public abstract class ABonusFrame extends JPanel {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ABonusFrame(int w, int h)
	{
		setBounds(0,0,w,h);
	}
}
