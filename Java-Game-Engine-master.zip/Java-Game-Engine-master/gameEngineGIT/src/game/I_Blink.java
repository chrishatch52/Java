package game;



/**
 * @author chris
 *
 */
public interface I_Blink {

	public String blink();
}
