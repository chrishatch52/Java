package game;



/**
 * 
 */

/**
 * @author Chris
 *
 */
public interface I_HeavyEquip extends I_Shield {
	
	public void addHarmor(AHeavyArmor heavyArmor);
	public void addHweapon(AHeavyWeapon sword);
	
}
