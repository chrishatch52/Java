/**
 * 
 */
package gfx;

import java.awt.Image;

/**
 * @author chris
 *
 */
public interface I_Tile {

	public Image getImage();
		
}
