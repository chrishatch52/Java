/**
 * 
 */
package gfx;

/**
 * @author chris
 *
 */
public class ItemTile extends ATile {

	/**
	 * 
	 */
	public ItemTile() {
		// TODO Auto-generated constructor stub
	}

}
