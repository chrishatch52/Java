package game;



/**
 * 
 */

/**
 * @author Chris
 *
 */
public interface I_TwoHand {

	public void addSecondWeapon(AWeapon secondWeapon);
	public AWeapon get_secondHand();
}
