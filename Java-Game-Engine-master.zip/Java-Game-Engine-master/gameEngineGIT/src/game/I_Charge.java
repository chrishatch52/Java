package game;



/**
 * 
 */

/**
 * @author Chris
 *
 */
public interface I_Charge {

	public String charge(AGameCharacter character);
}
