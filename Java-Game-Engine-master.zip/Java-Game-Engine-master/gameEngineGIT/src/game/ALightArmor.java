package game;


/**
 * @author chris
 *
 */
public class ALightArmor extends AArmor {
	
	public ALightArmor(String name, Bonus bonus, boolean equipped, String condition) 
	{
		super(name, bonus, equipped, condition);
	}

}
