/**
 * 
 */
package gfx;

import java.awt.Rectangle;

/**
 * @author chris
 *
 */
public class NormalTile extends AWalkableTile {

	/**
	 * 
	 */
	public NormalTile(ATile tile, Rectangle rect)
	{
		super(tile, rect);
	}

}
