package game;


/**
 * @author chris
 *
 */
public class DefenseBonus extends AStatBonus {

	/**
	 * @param rating
	 * @param type
	 */
	public DefenseBonus(int rating, String type) {
		super(rating, type);
		// TODO Auto-generated constructor stub
	}
	public DefenseBonus() {
		super(0, "");
	}
}
