package game;



/**
 * 
 */

/**
 * @author chris
 *
 */
public interface I_Smash {

	public void smash(AGameCharacter character);
}
